//
//  MenuListModel.swift
//  LittleLemonFoodOrderingApp
//
//  Created by Abdirahman Abdisalam on 23/05/23.
//

import Foundation

struct MenuList: Decodable {
    let menu: [MenuItem]
    
//    enum CodingKeys: String, CodingKey {
//        case menu = "menu"
//    }
}
