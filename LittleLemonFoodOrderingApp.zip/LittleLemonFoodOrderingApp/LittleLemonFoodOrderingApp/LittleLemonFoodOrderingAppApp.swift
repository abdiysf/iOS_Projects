//
//  LittleLemonFoodOrderingAppApp.swift
//  LittleLemonFoodOrderingApp
//
//  Created by Abdirahman Abdisalam on 22/05/23.
//

import SwiftUI

@main
struct LittleLemonFoodOrderingAppApp: App {

    var body: some Scene {
        WindowGroup {
            OnboardingView()
               
        }
    }
}
